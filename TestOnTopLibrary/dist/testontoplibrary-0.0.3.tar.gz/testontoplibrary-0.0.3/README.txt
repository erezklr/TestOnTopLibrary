# `ontoptest`

The `ontoptest` is a simple testing example to understand the basics of developing Python package. 

from multiply.by_three import multiply_by_three
from divide.by_three import divide_by_three

multiply_by_three(9)
divide_by_three(21)